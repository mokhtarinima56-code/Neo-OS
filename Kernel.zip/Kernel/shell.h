// kernel/shell.h
#ifndef SHELL_H
#define SHELL_H

void shell_print_prompt(void);
void shell_execute(char* input);

#endif