// kernel/screen.h
#ifndef SCREEN_H
#define SCREEN_H

void clear_screen(void);
void print(const char* str, unsigned char color);

#endif